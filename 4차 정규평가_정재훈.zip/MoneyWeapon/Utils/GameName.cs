﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyWeapon.Utils
{
    internal static class GameName
    {
        public static string gameName = " __    __                                                                           \r\n/ / /\\ \\ \\  ___   __ _  _ __    ___   _ __    _    /\\/\\    ___   _ __    ___  _   _ \r\n\\ \\/  \\/ / / _ \\ / _` || '_ \\  / _ \\ | '_ \\  (_)  /    \\  / _ \\ | '_ \\  / _ \\| | | |\r\n \\  /\\  / |  __/| (_| || |_) || (_) || | | |  _  / /\\/\\ \\| (_) || | | ||  __/| |_| |\r\n  \\/  \\/   \\___| \\__,_|| .__/  \\___/ |_| |_| (_) \\/    \\/ \\___/ |_| |_| \\___| \\__, |\r\n                       |_|                                                    |___/ ";
    }
}

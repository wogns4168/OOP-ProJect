﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyWeapon.Utils
{
    internal static class PlayerImage
    {
        public static string[] playerMoneyAttack =
{
            "      player  ",
            "       ___   ",
            "     ( o o ) ", 
            "   __ |  |/ === [$$$]", 
            "  [__]|__|   ", 
            "     /  \\    "  
};
    }
}
